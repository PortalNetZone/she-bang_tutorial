#!/usr/bin/env bash

pipenv install
pipenv shell
pipenv install grip
grip -b --title="Today let's see about She-Bang" --quiet SHE-BANG1.md 127.0.0.2
#echo "Quit the server..."
