# she-bang_tutorial
Learning about SHE-BANGs - See the first steps to make your own

Also, launched for Windows OS, this is a tutorial to learn about she-bangs.
This powerful tool allows you to both optimize and/or schedule several applications processes.
Those command lines were done to follow and auto-execute a linear, procedural step-by-step for a build process.

Instructions:

* Download and unpack this .zip file with "Extract to..." <file option>

* Then, right-click on the folder and "Open With..." <terminal option>
For Bash running terminals (i.e. Git Bash), just execute: ./.run-tuto
For Windows PowerShell terminal run: sh ./.run-tuto

Note: Don't worry about opening the tutorial. This process' going to auto-create a virtual environment for you, so the Python living in your system will keep untouchable.

